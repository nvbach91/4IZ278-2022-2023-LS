<?php
include_once("by_detection.php");
header('Location: main_user.php');
?>
